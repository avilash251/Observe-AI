"""
MCP Orchestrator
Coordinates the 5-agent pipeline using Model Context Protocol message routing.
Falls back to deterministic analysis when ANTHROPIC_API_KEY is absent.
"""
import json
import logging
import os
from typing import Any, AsyncGenerator, Dict

from anthropic import AsyncAnthropic

from agents import (
    AnomalyDetectorAgent,
    PredictorAgent,
    RootCauseAgent,
    MitigationAgent,
    DataCollectorAgent,
    AgentMessage,
)

logger = logging.getLogger(__name__)

_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
_MODEL   = "claude-sonnet-4-20250514"


class MCPOrchestrator:
    """
    MCP-style coordinator — routes work to the right specialist agent and
    optionally enriches analysis with Claude LLM intelligence.
    """

    def __init__(self):
        self._client = AsyncAnthropic(api_key=_API_KEY) if _API_KEY else None
        self._running = False

        # Instantiate all agents
        self.anomaly_detector = AnomalyDetectorAgent()
        self.predictor        = PredictorAgent()
        self.root_cause       = RootCauseAgent()
        self.mitigation       = MitigationAgent()
        self.data_collector   = DataCollectorAgent()

    # ── Lifecycle ─────────────────────────────────────────────────────────
    async def start(self):
        self._running = True
        llm_status = "Claude claude-sonnet-4-20250514" if self._client else "fallback (no API key)"
        logger.info(f"MCP Orchestrator started  LLM={llm_status}")

    async def stop(self):
        self._running = False

    # ── Agent registry ────────────────────────────────────────────────────
    async def get_agent_status(self) -> Dict[str, Any]:
        return {
            a.agent_id: a.get_info()
            for a in [
                self.anomaly_detector,
                self.predictor,
                self.root_cause,
                self.mitigation,
                self.data_collector,
            ]
        }

    # ── Pipeline: Anomaly analysis ────────────────────────────────────────
    async def analyze_anomaly(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Full pipeline:
          DataCollector → AnomalyDetector → RootCause → Mitigation → [LLM enrich]
        """
        # 1. Detect
        detect_msg = AgentMessage(
            sender="orchestrator", recipient="anomaly_detector",
            msg_type="request", payload={"metrics": payload.get("metrics", payload)},
        )
        detect_resp = await self.anomaly_detector.process_message(detect_msg)
        anomalies = detect_resp.payload.get("anomalies", []) if detect_resp else []

        # 2. Root cause
        rc_msg = AgentMessage(
            sender="orchestrator", recipient="root_cause",
            msg_type="request", payload={"anomalies": anomalies},
        )
        rc_resp = await self.root_cause.process_message(rc_msg)
        root_causes = rc_resp.payload.get("root_causes", []) if rc_resp else []

        # 3. Mitigation
        mit_msg = AgentMessage(
            sender="orchestrator", recipient="mitigation",
            msg_type="request",
            payload={"anomalies": anomalies, "root_causes": root_causes},
        )
        mit_resp = await self.mitigation.process_message(mit_msg)
        mitigation_steps = mit_resp.payload.get("mitigation_steps", []) if mit_resp else []

        # 4. LLM enrichment
        if self._client and anomalies:
            try:
                result = await self._llm_enrich_analysis(
                    payload, anomalies, root_causes, mitigation_steps
                )
                return result
            except Exception as exc:
                logger.warning(f"LLM enrichment failed: {exc} — using local analysis")

        # Fallback: assemble locally
        health = max(0, 100 - len(anomalies) * 15 -
                     sum(8 for a in anomalies if a.get("severity") == "critical"))
        return {
            "anomalies":        anomalies,
            "root_causes":      root_causes,
            "mitigation_steps": mitigation_steps,
            "overall_health_score": health,
            "summary": (
                f"Detected {len(anomalies)} anomalies across monitored services. "
                "Review mitigation steps and execute recommended actions."
                if anomalies else "All metrics within normal bounds."
            ),
        }

    # ── Pipeline: Prediction ──────────────────────────────────────────────
    async def predict_future(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        pred_msg = AgentMessage(
            sender="orchestrator", recipient="predictor",
            msg_type="request", payload={"metrics": payload},
        )
        pred_resp = await self.predictor.process_message(pred_msg)
        if not pred_resp:
            return {}

        raw_preds   = pred_resp.payload.get("predictions", {})
        capacity    = pred_resp.payload.get("capacity_forecast", {})

        # Shape into response model
        predictions = []
        for key, pts in raw_preds.items():
            if not pts:
                continue
            svc, metric = (key.split(".", 1) + ["unknown"])[:2]
            current = payload.get(key, 0)
            trend_vals = [p["predicted_value"] for p in pts]
            if len(trend_vals) >= 2:
                trend = ("increasing" if trend_vals[-1] > trend_vals[0] * 1.05
                         else "decreasing" if trend_vals[-1] < trend_vals[0] * 0.95
                         else "stable")
            else:
                trend = "stable"
            predictions.append({
                "metric":               metric,
                "service":              svc,
                "current_value":        round(current, 2),
                "predictions":          pts,
                "trend":                trend,
                "risk_level":           "high" if trend == "increasing" and current > 70 else "medium",
                "will_breach_threshold": any(p["predicted_value"] > 90 for p in pts),
                "breach_time_minutes":  next(
                    (p["time_offset_minutes"] for p in pts if p["predicted_value"] > 90), None
                ),
            })

        actions = []
        if capacity.get("cpu_exhaustion_minutes"):
            actions.append("⚡ Enable auto-scaling immediately — CPU exhaustion imminent")
        if capacity.get("memory_exhaustion_minutes"):
            actions.append("🧠 Trigger heap profiling — memory will be exhausted soon")
        if not actions:
            actions.append("System trajectory is stable — no immediate action required")

        return {
            "predictions":        predictions,
            "capacity_forecast":  capacity,
            "recommended_actions": actions,
            "confidence_score":   0.80,
        }

    # ── LLM enrichment ────────────────────────────────────────────────────
    async def _llm_enrich_analysis(
        self,
        payload, anomalies, root_causes, mitigation_steps
    ) -> Dict[str, Any]:
        system = (
            "You are the ObservaAI MCP Orchestrator coordinating 5 specialist agents "
            "(AnomalyDetector, PredictorAgent, RootCauseAgent, MitigationAgent, DataCollector). "
            "Respond ONLY with valid JSON. Do not add markdown code fences."
        )
        user = f"""Agent pipeline has already produced:
ANOMALIES:
{json.dumps(anomalies, indent=2)}

ROOT CAUSES:
{json.dumps(root_causes, indent=2)}

MITIGATION STEPS:
{json.dumps(mitigation_steps, indent=2)}

Enrich and return the final analysis as JSON:
{{
  "anomalies": [...],
  "root_causes": [...],
  "mitigation_steps": [...],
  "overall_health_score": <0-100>,
  "summary": "<2-3 sentence executive summary>"
}}"""

        resp = await self._client.messages.create(
            model=_MODEL, max_tokens=2000,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        text = resp.content[0].text.strip()
        start, end = text.find("{"), text.rfind("}") + 1
        return json.loads(text[start:end])

    # ── Streaming agent chat ───────────────────────────────────────────────
    async def stream_agent_response(self, query: str) -> AsyncGenerator[str, None]:
        if not self._client:
            yield self._mock_response(query)
            return

        system = """You are the ObservaAI multi-agent coordinator.
You manage 5 agents: AnomalyDetector, PredictorAgent, RootCauseAgent, MitigationAgent, DataCollector.
Respond conversationally, prefixing each agent's contribution with [AgentName].
Be concise and actionable."""

        async with self._client.messages.stream(
            model=_MODEL, max_tokens=1200,
            system=system,
            messages=[{"role": "user", "content": query}],
        ) as stream:
            async for chunk in stream.text_stream:
                yield chunk

    @staticmethod
    def _mock_response(query: str) -> str:
        return f"""[Coordinator] Processing: "{query}"

[DataCollector] Ingesting 847 time-series metrics across 6 services.

[AnomalyDetector] Found 2 deviations above 2.5σ:
  • api-gateway.cpu_usage: 87.3% (baseline 42%)
  • auth-service.response_time_p99: 1847ms (baseline 220ms)

[RootCauseAgent] Tracing dependency graph…
  Root cause: Traffic spike (3× normal) hitting api-gateway without auto-scaling.
  Blast radius: 3 services. Confidence: 82%.

[PredictorAgent] Current trajectory → CPU will reach 95% in ~18 minutes.
  Memory stable. Disk: 48 hours to threshold.

[MitigationAgent] Priority actions:
  1. [AUTO] kubectl scale deployment api-gateway --replicas=+2
  2. [AUTO] Enable Redis caching (60% DB load reduction)
  3. [MANUAL] Review load-balancer upstream weights

[Coordinator] Overall health: 58/100. Immediate auto-scaling recommended."""
