"""
WebSocket Connection Manager
Tracks all active client connections and provides broadcast / unicast helpers.
"""
import logging
from typing import Dict

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:

    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, client_id: str) -> None:
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.debug(f"WS connect: {client_id} ({len(self.active_connections)} total)")

    def disconnect(self, client_id: str) -> None:
        self.active_connections.pop(client_id, None)
        logger.debug(f"WS disconnect: {client_id} ({len(self.active_connections)} total)")

    async def broadcast(self, message: str) -> None:
        stale = []
        for cid, ws in self.active_connections.items():
            try:
                await ws.send_text(message)
            except Exception:
                stale.append(cid)
        for cid in stale:
            self.disconnect(cid)

    async def send_to(self, client_id: str, message: str) -> None:
        ws = self.active_connections.get(client_id)
        if ws:
            try:
                await ws.send_text(message)
            except Exception:
                self.disconnect(client_id)
