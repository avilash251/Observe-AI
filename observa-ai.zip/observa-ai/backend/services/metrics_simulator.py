"""
MetricsSimulator
Generates realistic production observability data with:
  - Diurnal (sine-wave) CPU / RPS patterns
  - Memory growth with occasional resets
  - Injected random incidents (CPU spike + latency + error rate)
  - Per-service independent variance
"""
import math
import random
from datetime import datetime
from typing import Dict, Any, List


class MetricsSimulator:

    SERVICES = [
        "api-gateway",
        "auth-service",
        "user-service",
        "payment-service",
        "notification-service",
        "fraud-detection",
    ]

    # Services affected when an incident fires
    INCIDENT_TARGETS = ["api-gateway", "auth-service"]

    def __init__(self):
        self._tick = 0
        self._incident_active = False
        self._incident_ticks_left = 0
        self._incident_countdown = random.randint(25, 50)
        self._history: Dict[str, List[float]] = {s: [] for s in self.SERVICES}

    async def generate_metrics(self) -> Dict[str, Any]:
        self._tick += 1
        self._incident_countdown -= 1

        # Fire incident
        if self._incident_countdown <= 0:
            self._incident_active     = True
            self._incident_ticks_left = random.randint(8, 18)
            self._incident_countdown  = random.randint(35, 70)

        if self._incident_active:
            self._incident_ticks_left -= 1
            if self._incident_ticks_left <= 0:
                self._incident_active = False

        services_data = {
            svc: self._service_metrics(svc)
            for svc in self.SERVICES
        }
        global_data = self._global_metrics()

        return {
            "services":       services_data,
            "global":         global_data,
            "timestamp":      datetime.utcnow().isoformat(),
            "anomaly_active": self._incident_active,
            "health_score":   self._health_score(services_data),
        }

    # ── Per-service ───────────────────────────────────────────────────────
    def _service_metrics(self, service: str) -> Dict[str, Any]:
        t = self._tick
        affected = self._incident_active and service in self.INCIDENT_TARGETS

        # CPU — diurnal + spike
        base_cpu = 30 + 18 * math.sin(t * 0.05 + hash(service) % 6) + random.gauss(0, 3)
        cpu = min(97, base_cpu + (random.uniform(28, 48) if affected else 0))

        # Memory — slow leak pattern that resets occasionally
        leak   = 0.08 * (t % 300)
        base_m = 52 + leak + random.gauss(0, 2)
        memory = min(96, base_m + (random.uniform(12, 25) if affected else 0))

        # Response times correlated with CPU
        rt_base = 120 + 40 * math.sin(t * 0.03) + random.gauss(0, 15)
        rt_p50  = max(5.0, rt_base + (cpu - 40) * 3.5)
        rt_p99  = rt_p50 * random.uniform(3.8, 6.5)

        # Error rate
        base_err = max(0.0, random.gauss(0.4, 0.25))
        error_rate = base_err + (random.uniform(10, 20) if affected else 0)

        # RPS
        base_rps = 400 + 180 * math.sin(t * 0.04) + random.gauss(0, 25)
        rps = max(5.0, base_rps + (random.uniform(80, 250) if affected else 0))

        return {
            "cpu_usage":          round(cpu,        2),
            "memory_usage":       round(memory,     2),
            "response_time_p50":  round(rt_p50,     1),
            "response_time_p99":  round(rt_p99,     1),
            "error_rate":         round(max(0.0, error_rate), 3),
            "request_rate":       round(rps,        1),
            "throughput":         round(rps * (1 - error_rate / 100) * random.uniform(0.9, 1.1), 1),
            "queue_depth":        max(0, int(cpu / 10 - 3 + random.gauss(0, 2))),
            "active_connections": int(rps / 8),
            "gc_pause_ms":        round(random.expovariate(1 / 12), 1),
            "disk_io_read":       round(random.uniform(4, 90), 1),
            "disk_io_write":      round(random.uniform(1, 45), 1),
            "status":             "degraded" if affected else "healthy",
        }

    def _global_metrics(self) -> Dict[str, Any]:
        t = self._tick
        return {
            "total_requests_per_second": round(1700 + 380 * math.sin(t * 0.04) + random.gauss(0, 40), 1),
            "cluster_cpu_usage":         round(42  + 14 * math.sin(t * 0.05)  + random.gauss(0, 4), 2),
            "cluster_memory_usage":      round(60  +  9 * math.sin(t * 0.03)  + random.gauss(0, 2), 2),
            "active_pods":               24 + random.randint(-1, 1),
            "network_in_mbps":           round(random.uniform(38, 130), 1),
            "network_out_mbps":          round(random.uniform(18, 85),  1),
            "disk_usage_percent":        round(66 + random.uniform(-0.5, 0.5), 1),
            "open_alerts":               random.randint(0, 4) + (4 if self._incident_active else 0),
            "slo_compliance":            round(99.9 - random.uniform(0, 0.4)
                                              - (1.4 if self._incident_active else 0), 3),
        }

    @staticmethod
    def _health_score(services_data: Dict) -> int:
        score = 100
        for metrics in services_data.values():
            if metrics["cpu_usage"]         > 80:  score -= 8
            if metrics["memory_usage"]      > 85:  score -= 6
            if metrics["error_rate"]        > 5:   score -= 10
            if metrics["response_time_p99"] > 2000: score -= 7
        return max(0, min(100, score))

    @property
    def history(self):
        return self._history
