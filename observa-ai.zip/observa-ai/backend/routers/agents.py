"""Agents REST router"""
from fastapi import APIRouter
from mcp.orchestrator import MCPOrchestrator

router = APIRouter()
_orc = MCPOrchestrator()


@router.get("/status")
async def status():
    return await _orc.get_agent_status()


@router.get("/registry")
async def registry():
    agents = await _orc.get_agent_status()
    return {
        "total_agents": len(agents),
        "framework":    "Google ADK + MCP Orchestrator",
        "transport":    "WebSocket + async message passing",
        "llm_backend":  "Anthropic Claude claude-sonnet-4-20250514",
        "agents":       agents,
    }
