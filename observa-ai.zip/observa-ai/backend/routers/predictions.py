"""Predictions REST router"""
from fastapi import APIRouter
from models.schemas import PredictionRequest
from mcp.orchestrator import MCPOrchestrator

router = APIRouter()
_orc = MCPOrchestrator()


@router.post("/forecast")
async def forecast(request: PredictionRequest):
    return await _orc.predict_future(request.model_dump())
