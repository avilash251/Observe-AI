"""Metrics REST router"""
from fastapi import APIRouter
from services.metrics_simulator import MetricsSimulator

router = APIRouter()
_sim = MetricsSimulator()


@router.get("/current")
async def current_metrics():
    """Snapshot of current metrics for all services."""
    return await _sim.generate_metrics()


@router.get("/services")
async def list_services():
    return {"services": _sim.SERVICES}
