"""Anomalies REST router"""
from fastapi import APIRouter
from models.schemas import AnomalyAnalysisRequest
from mcp.orchestrator import MCPOrchestrator

router = APIRouter()
_orc = MCPOrchestrator()


@router.post("/analyze")
async def analyze(request: AnomalyAnalysisRequest):
    return await _orc.analyze_anomaly(request.model_dump())


@router.get("/history")
async def history():
    return {"message": "Use WebSocket for real-time anomaly stream", "anomalies": []}
