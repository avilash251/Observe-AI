"""
ObservaAI — Main Application Entry Point
FastAPI + WebSocket server with multi-agent pipeline
"""
import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from mcp.orchestrator import MCPOrchestrator
from routers import metrics, anomalies, predictions, agents
from services.metrics_simulator import MetricsSimulator
from services.websocket_manager import ConnectionManager

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ── Singletons ──────────────────────────────────────────────────────────────
manager = ConnectionManager()
simulator = MetricsSimulator()
orchestrator = MCPOrchestrator()


# ── Lifespan ─────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀  ObservaAI starting …")
    asyncio.create_task(stream_metrics_loop())
    await orchestrator.start()
    yield
    logger.info("🛑  ObservaAI shutting down …")
    await orchestrator.stop()


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="ObservaAI",
    description="AI-powered Anomaly Detection & Predictive Analytics — Multi-Agent Platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(metrics.router,     prefix="/api/metrics",     tags=["Metrics"])
app.include_router(anomalies.router,   prefix="/api/anomalies",   tags=["Anomalies"])
app.include_router(predictions.router, prefix="/api/predictions", tags=["Predictions"])
app.include_router(agents.router,      prefix="/api/agents",      tags=["Agents"])


# ── Background metric stream ──────────────────────────────────────────────────
async def stream_metrics_loop():
    """Generate metrics every 2 s and broadcast to all WebSocket clients."""
    while True:
        try:
            data = await simulator.generate_metrics()
            if manager.active_connections:
                await manager.broadcast(json.dumps({
                    "type": "metrics_update",
                    "timestamp": datetime.utcnow().isoformat(),
                    "data": data,
                }))
        except Exception as exc:
            logger.error(f"Metric stream error: {exc}")
        await asyncio.sleep(2)


# ── WebSocket endpoint ────────────────────────────────────────────────────────
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(websocket, client_id)
    logger.info(f"Client connected: {client_id}  (total={len(manager.active_connections)})")

    try:
        await websocket.send_json({
            "type": "connection_ack",
            "client_id": client_id,
            "message": "Connected to ObservaAI",
            "timestamp": datetime.utcnow().isoformat(),
        })

        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)
            msg_type = msg.get("type")

            if msg_type == "analyze_anomaly":
                asyncio.create_task(_handle_analyze(websocket, msg))
            elif msg_type == "predict":
                asyncio.create_task(_handle_predict(websocket, msg))
            elif msg_type == "agent_query":
                asyncio.create_task(_handle_agent_query(websocket, msg))

    except WebSocketDisconnect:
        manager.disconnect(client_id)
        logger.info(f"Client disconnected: {client_id}")
    except Exception as exc:
        logger.error(f"WS error ({client_id}): {exc}")
        manager.disconnect(client_id)


async def _handle_analyze(ws: WebSocket, msg: dict):
    try:
        await ws.send_json({
            "type": "agent_thinking",
            "agent": "anomaly_detector",
            "message": "⚡ AnomalyDetector scanning metrics …",
            "timestamp": datetime.utcnow().isoformat(),
        })
        result = await orchestrator.analyze_anomaly(msg.get("payload", {}))
        await ws.send_json({"type": "anomaly_result", "data": result,
                            "timestamp": datetime.utcnow().isoformat()})
    except Exception as exc:
        await ws.send_json({"type": "error", "message": str(exc)})


async def _handle_predict(ws: WebSocket, msg: dict):
    try:
        await ws.send_json({
            "type": "agent_thinking",
            "agent": "predictor",
            "message": "🔮 PredictorAgent forecasting next 30 minutes …",
            "timestamp": datetime.utcnow().isoformat(),
        })
        result = await orchestrator.predict_future(msg.get("payload", {}))
        await ws.send_json({"type": "prediction_result", "data": result,
                            "timestamp": datetime.utcnow().isoformat()})
    except Exception as exc:
        await ws.send_json({"type": "error", "message": str(exc)})


async def _handle_agent_query(ws: WebSocket, msg: dict):
    try:
        await ws.send_json({
            "type": "agent_thinking",
            "agent": "coordinator",
            "message": "🤖 MCP Coordinator routing query to specialist agents …",
            "timestamp": datetime.utcnow().isoformat(),
        })
        async for chunk in orchestrator.stream_agent_response(msg.get("query", "")):
            await ws.send_json({"type": "agent_stream", "chunk": chunk,
                                "timestamp": datetime.utcnow().isoformat()})
        await ws.send_json({"type": "agent_complete",
                            "timestamp": datetime.utcnow().isoformat()})
    except Exception as exc:
        await ws.send_json({"type": "error", "message": str(exc)})


# ── Health ─────────────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {"service": "ObservaAI", "status": "online", "version": "1.0.0"}


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "agents": await orchestrator.get_agent_status(),
        "ws_connections": len(manager.active_connections),
        "timestamp": datetime.utcnow().isoformat(),
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
