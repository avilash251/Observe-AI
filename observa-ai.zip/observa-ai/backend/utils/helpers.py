"""Shared utility functions"""
import json
from datetime import datetime
from typing import Any


def now_iso() -> str:
    return datetime.utcnow().isoformat()


def safe_json_extract(text: str) -> Any:
    """Extract first JSON object from a string (strips markdown fences etc.)."""
    start = text.find("{")
    end   = text.rfind("}") + 1
    if start == -1 or end <= start:
        return None
    try:
        return json.loads(text[start:end])
    except json.JSONDecodeError:
        return None


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))
