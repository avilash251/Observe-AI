"""
Pydantic schemas for request/response validation
"""
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# ── Metrics ───────────────────────────────────────────────────────────────────
class ServiceMetrics(BaseModel):
    cpu_usage: float
    memory_usage: float
    response_time_p50: float
    response_time_p99: float
    error_rate: float
    request_rate: float
    throughput: float
    queue_depth: int
    active_connections: int
    gc_pause_ms: float
    disk_io_read: float
    disk_io_write: float
    status: str


class GlobalMetrics(BaseModel):
    total_requests_per_second: float
    cluster_cpu_usage: float
    cluster_memory_usage: float
    active_pods: int
    network_in_mbps: float
    network_out_mbps: float
    disk_usage_percent: float
    open_alerts: int
    slo_compliance: float


class MetricsSnapshot(BaseModel):
    services: Dict[str, ServiceMetrics]
    global_: GlobalMetrics = Field(alias="global")
    timestamp: str
    anomaly_active: bool
    health_score: int


# ── Anomaly Analysis ──────────────────────────────────────────────────────────
class AnomalyAnalysisRequest(BaseModel):
    metrics: Dict[str, Any]
    service: str = "all"


class AnomalyItem(BaseModel):
    id: str
    severity: str  # critical | high | medium | low
    metric: str
    current_value: Optional[float] = None
    expected_range: Optional[Dict[str, float]] = None
    deviation_percent: Optional[float] = None
    affected_service: Optional[str] = None
    description: Optional[str] = None
    z_score: Optional[float] = None


class RootCauseItem(BaseModel):
    anomaly_id: str
    cause: str
    confidence: float
    evidence: List[str]
    affected_services: Optional[List[str]] = None
    blast_radius: Optional[int] = None


class MitigationStep(BaseModel):
    priority: int
    action: str
    command: Optional[str] = None
    estimated_impact: str
    automation_possible: bool
    severity: Optional[str] = None
    runbook_url: Optional[str] = None


class AnomalyAnalysisResponse(BaseModel):
    anomalies: List[AnomalyItem]
    root_causes: List[RootCauseItem]
    mitigation_steps: List[MitigationStep]
    overall_health_score: int
    summary: str


# ── Predictions ───────────────────────────────────────────────────────────────
class PredictionRequest(BaseModel):
    metrics: Dict[str, float]
    horizon_minutes: int = 30


class PredictionPoint(BaseModel):
    time_offset_minutes: int
    predicted_value: float
    confidence_lower: float
    confidence_upper: float


class MetricPrediction(BaseModel):
    metric: str
    service: str
    current_value: float
    predictions: List[PredictionPoint]
    trend: str  # increasing | decreasing | stable | volatile
    risk_level: str
    will_breach_threshold: bool
    breach_time_minutes: Optional[int] = None


class CapacityForecast(BaseModel):
    cpu_exhaustion_minutes: Optional[int] = None
    memory_exhaustion_minutes: Optional[int] = None
    disk_exhaustion_hours: Optional[int] = None


class PredictionResponse(BaseModel):
    predictions: List[MetricPrediction]
    capacity_forecast: CapacityForecast
    recommended_actions: List[str]
    confidence_score: float


# ── Agent ──────────────────────────────────────────────────────────────────────
class AgentInfo(BaseModel):
    agent_id: str
    name: str
    description: str
    status: str
    tools: List[str]
    tasks_completed: int


class AgentQueryRequest(BaseModel):
    query: str
