"""
PredictorAgent
Time-series forecasting via exponential smoothing + linear trend extrapolation.
"""
import math
import random
from typing import Dict, List, Optional

from agents.base_agent import BaseAgent, AgentMessage


class PredictorAgent(BaseAgent):

    FORECAST_STEPS = 6      # 6 × 5 min = 30-minute horizon
    HISTORY_LIMIT  = 60

    def __init__(self):
        super().__init__(
            agent_id="predictor",
            name="Predictive Analytics Agent",
            description="30-minute metric forecasting with confidence intervals",
        )
        self.register_tools([
            "exponential_smoothing",
            "linear_trend_extrapolation",
            "confidence_interval_builder",
            "capacity_planner",
            "breach_time_estimator",
        ])
        self._history: Dict[str, List[float]] = {}

    # ── History ────────────────────────────────────────────────────────────
    def _push(self, key: str, value: float) -> None:
        if key not in self._history:
            self._history[key] = []
        self._history[key].append(value)
        if len(self._history[key]) > self.HISTORY_LIMIT:
            self._history[key].pop(0)

    # ── Smoothing ──────────────────────────────────────────────────────────
    @staticmethod
    def _exp_smooth(values: List[float], alpha: float = 0.3) -> List[float]:
        if not values:
            return []
        result = [values[0]]
        for v in values[1:]:
            result.append(alpha * v + (1 - alpha) * result[-1])
        return result

    # ── Forecast ───────────────────────────────────────────────────────────
    def forecast(self, key: str, steps: int = None) -> List[Dict]:
        steps = steps or self.FORECAST_STEPS
        history = self._history.get(key, [])
        if len(history) < 3:
            return []

        smoothed = self._exp_smooth(history)
        last = smoothed[-1]

        # Compute trend from last 5 smoothed points
        recent = smoothed[-5:] if len(smoothed) >= 5 else smoothed
        trend = (recent[-1] - recent[0]) / max(1, len(recent) - 1)

        points = []
        for i in range(1, steps + 1):
            noise = random.gauss(0, max(0.3, abs(last) * 0.015))
            pred = max(0.0, last + trend * i + noise)
            ci = abs(last) * 0.04 * math.sqrt(i)
            points.append({
                "time_offset_minutes": i * 5,
                "predicted_value":   round(pred, 2),
                "confidence_lower":  round(max(0.0, pred - ci), 2),
                "confidence_upper":  round(pred + ci, 2),
            })
        return points

    # ── Capacity planning ──────────────────────────────────────────────────
    def capacity_forecast(self, flat_metrics: Dict[str, float]) -> Dict:
        result: Dict = {}
        for key, val in flat_metrics.items():
            history = self._history.get(key, [])
            if len(history) < 5:
                continue

            smoothed = self._exp_smooth(history)
            recent = smoothed[-5:]
            trend = (recent[-1] - recent[0]) / 4

            metric = key.split(".", 1)[-1]
            if "cpu" in metric and trend > 0 and val > 60:
                mins_to_90 = (90 - val) / trend if trend > 0 else None
                if mins_to_90 and 0 < mins_to_90 < 120:
                    result["cpu_exhaustion_minutes"] = int(mins_to_90)
            elif "memory" in metric and trend > 0 and val > 65:
                mins_to_95 = (95 - val) / trend if trend > 0 else None
                if mins_to_95 and 0 < mins_to_95 < 120:
                    result["memory_exhaustion_minutes"] = int(mins_to_95)
            elif "disk" in metric and trend > 0:
                hrs_to_95 = (95 - val) / (trend * 30) if trend > 0 else None
                if hrs_to_95 and 0 < hrs_to_95 < 72:
                    result["disk_exhaustion_hours"] = int(hrs_to_95)

        return result

    # ── BaseAgent interface ────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        self._begin_task()
        try:
            flat = message.payload.get("metrics", {})
            for key, val in flat.items():
                self._push(key, val)

            predictions = {key: self.forecast(key) for key in flat if self.forecast(key)}
            capacity    = self.capacity_forecast(flat)

            self._end_task()
            return AgentMessage(
                sender=self.agent_id,
                recipient=message.sender,
                msg_type="response",
                payload={"predictions": predictions, "capacity_forecast": capacity},
                correlation_id=message.correlation_id,
            )
        except Exception:
            self.status = "idle"
            raise
