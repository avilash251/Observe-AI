"""
DataCollectorAgent
Normalises and routes raw metric payloads from all instrumented services.
"""
from typing import Any, Dict, Optional

from agents.base_agent import BaseAgent, AgentMessage


class DataCollectorAgent(BaseAgent):

    def __init__(self):
        super().__init__(
            agent_id="data_collector",
            name="Data Collector Agent",
            description="Metrics ingestion, normalisation, and routing across all services",
        )
        self.register_tools([
            "prometheus_scraper",
            "log_line_parser",
            "trace_span_collector",
            "metric_normaliser",
            "cardinality_limiter",
        ])
        self.status = "active"   # always active — continuously ingesting
        self._ingestion_count = 0

    # ── Normalisation ──────────────────────────────────────────────────────
    @staticmethod
    def normalise(raw: Dict[str, Any]) -> Dict[str, float]:
        return {
            k: round(float(v), 4)
            for k, v in raw.items()
            if isinstance(v, (int, float))
        }

    # ── BaseAgent interface ────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        # DataCollector never goes idle
        self.status = "active"
        try:
            raw        = message.payload.get("raw_metrics", {})
            normalised = self.normalise(raw)
            self._ingestion_count += 1
            self.tasks_completed  += 1
            return AgentMessage(
                sender=self.agent_id,
                recipient=message.sender,
                msg_type="response",
                payload={
                    "normalised_metrics": normalised,
                    "ingestion_count":    self._ingestion_count,
                },
                correlation_id=message.correlation_id,
            )
        finally:
            self.status = "active"
