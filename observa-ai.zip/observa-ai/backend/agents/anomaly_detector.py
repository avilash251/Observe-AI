"""
AnomalyDetectorAgent
Uses Z-score analysis + dynamic baseline learning to detect metric anomalies.
"""
import math
import random
from datetime import datetime
from typing import Dict, List, Optional

from agents.base_agent import BaseAgent, AgentMessage


class AnomalyDetectorAgent(BaseAgent):

    # Per-metric thresholds: (warn_low, warn_high)
    THRESHOLDS: Dict[str, tuple] = {
        "cpu_usage":          (10.0,  80.0),
        "memory_usage":       (20.0,  85.0),
        "error_rate":         (0.0,    5.0),
        "response_time_p99":  (50.0, 1000.0),
        "disk_usage":         (10.0,  90.0),
        "queue_depth":        (0.0,   50.0),
    }

    def __init__(self):
        super().__init__(
            agent_id="anomaly_detector",
            name="Anomaly Detector Agent",
            description="Statistical anomaly detection — Z-score + dynamic baselines",
        )
        self.register_tools([
            "z_score_analysis",
            "threshold_checker",
            "baseline_learner",
            "severity_classifier",
        ])
        # metric → {"values": [...], "mean": float, "std": float}
        self._baselines: Dict[str, Dict] = {}

    # ── Baseline helpers ───────────────────────────────────────────────────
    def _update_baseline(self, metric: str, value: float) -> None:
        if metric not in self._baselines:
            self._baselines[metric] = {"values": [], "mean": 0.0, "std": 1.0}
        buf = self._baselines[metric]["values"]
        buf.append(value)
        if len(buf) > 120:
            buf.pop(0)
        mean = sum(buf) / len(buf)
        std = math.sqrt(sum((x - mean) ** 2 for x in buf) / len(buf)) if len(buf) > 1 else 1.0
        self._baselines[metric]["mean"] = mean
        self._baselines[metric]["std"] = max(0.01, std)

    def _z_score(self, metric: str, value: float) -> float:
        b = self._baselines.get(metric)
        if not b:
            return 0.0
        return abs(value - b["mean"]) / b["std"]

    # ── Detection ──────────────────────────────────────────────────────────
    def detect(self, flat_metrics: Dict[str, float]) -> List[Dict]:
        """
        flat_metrics: {"service.metric_name": value, …}
        Returns list of anomaly dicts.
        """
        anomalies = []
        for key, value in flat_metrics.items():
            parts = key.split(".", 1)
            service = parts[0] if len(parts) == 2 else "unknown"
            metric  = parts[1] if len(parts) == 2 else key

            self._update_baseline(key, value)
            z = self._z_score(key, value)

            lo, hi = self.THRESHOLDS.get(metric, (None, None))
            threshold_breach = (lo is not None and value < lo) or \
                               (hi is not None and value > hi)

            if z > 2.5 or threshold_breach:
                sev = (
                    "critical" if z > 3.5 or (metric == "error_rate" and value > 15)
                    else "high"   if z > 2.8 or threshold_breach
                    else "medium"
                )
                expected = self.THRESHOLDS.get(metric, {})
                anomalies.append({
                    "id": f"anom-{metric}-{int(datetime.utcnow().timestamp())}",
                    "metric": metric,
                    "value": round(value, 3),
                    "z_score": round(z, 2),
                    "severity": sev,
                    "affected_service": service,
                    "baseline_mean": round(self._baselines[key]["mean"], 2),
                    "threshold_breach": threshold_breach,
                    "expected_range": {
                        "min": expected[0] if expected else None,
                        "max": expected[1] if expected else None,
                    },
                    "detected_at": datetime.utcnow().isoformat(),
                })

        return anomalies

    # ── BaseAgent interface ────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        self._begin_task()
        try:
            metrics = message.payload.get("metrics", {})
            anomalies = self.detect(metrics)
            self._end_task()
            return AgentMessage(
                sender=self.agent_id,
                recipient=message.sender,
                msg_type="response",
                payload={"anomalies": anomalies},
                correlation_id=message.correlation_id,
            )
        except Exception:
            self.status = "idle"
            raise
