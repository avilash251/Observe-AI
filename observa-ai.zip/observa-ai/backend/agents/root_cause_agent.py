"""
RootCauseAgent
Traces anomalies through a service-dependency graph to identify probable root causes.
"""
from typing import Dict, List, Optional

from agents.base_agent import BaseAgent, AgentMessage


SERVICE_GRAPH: Dict[str, List[str]] = {
    "api-gateway":         ["auth-service", "user-service", "payment-service"],
    "auth-service":        ["postgres-db", "redis-cache"],
    "user-service":        ["postgres-db", "object-storage"],
    "payment-service":     ["postgres-db", "stripe-api", "fraud-detection"],
    "fraud-detection":     ["ml-service"],
    "notification-service":["smtp-relay", "sms-gateway"],
}

PATTERN_LIBRARY = {
    "cpu": {
        "cause": "Resource exhaustion — likely traffic spike or inefficient hot-path code",
        "confidence": 0.82,
        "evidence_templates": [
            "CPU trend increasing over last 10 minutes",
            "No correlated deployment event detected",
            "Upstream service showing elevated RPS",
        ],
    },
    "memory": {
        "cause": "Memory pressure — possible leak or large object retention",
        "confidence": 0.78,
        "evidence_templates": [
            "Memory growth is monotonic (linear leak pattern)",
            "GC pause duration increasing",
            "Heap old-gen approaching saturation",
        ],
    },
    "error_rate": {
        "cause": "Downstream dependency failure causing cascading errors",
        "confidence": 0.76,
        "evidence_templates": [
            "Error codes cluster around DB connection timeouts",
            "Circuit-breaker state: half-open",
            "Retry storms visible in request logs",
        ],
    },
    "response_time": {
        "cause": "Latency spike — DB slow-query or lock contention",
        "confidence": 0.74,
        "evidence_templates": [
            "P99 diverging from P50 (indicates outlier requests)",
            "DB query plan regression detected",
            "Lock wait times elevated on primary replica",
        ],
    },
    "queue_depth": {
        "cause": "Consumer lag — worker pool undersized for current load",
        "confidence": 0.71,
        "evidence_templates": [
            "Queue depth growing linearly",
            "Consumer throughput has not scaled with producer rate",
        ],
    },
}


class RootCauseAgent(BaseAgent):

    def __init__(self):
        super().__init__(
            agent_id="root_cause",
            name="Root Cause Analyzer",
            description="Service-dependency graph tracing + pattern-matched root cause analysis",
        )
        self.register_tools([
            "dependency_graph_walker",
            "correlation_matrix",
            "event_timeline",
            "pattern_matcher",
            "blast_radius_calculator",
        ])

    # ── Analysis ───────────────────────────────────────────────────────────
    def analyze(self, anomalies: List[Dict]) -> List[Dict]:
        results = []
        for anomaly in anomalies:
            metric  = anomaly.get("metric", "")
            service = anomaly.get("affected_service", "unknown")

            # Match pattern
            pattern_key = next(
                (k for k in PATTERN_LIBRARY if k in metric), None
            )
            if pattern_key:
                p = PATTERN_LIBRARY[pattern_key]
                cause      = p["cause"]
                confidence = p["confidence"]
                evidence   = list(p["evidence_templates"])
            else:
                cause      = f"Anomalous behaviour in {service} — further investigation required"
                confidence = 0.55
                evidence   = ["Metric deviation exceeds 2σ from learned baseline"]

            # Blast radius
            deps = SERVICE_GRAPH.get(service, [])
            affected = [service] + deps[:3]
            blast_radius = len(affected)

            results.append({
                "anomaly_id":       anomaly.get("id", ""),
                "cause":            cause,
                "confidence":       round(confidence, 2),
                "evidence":         evidence,
                "affected_services": affected,
                "blast_radius":     blast_radius,
            })

        return results

    # ── BaseAgent interface ────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        self._begin_task()
        try:
            anomalies = message.payload.get("anomalies", [])
            root_causes = self.analyze(anomalies)
            self._end_task()
            return AgentMessage(
                sender=self.agent_id,
                recipient=message.sender,
                msg_type="response",
                payload={"root_causes": root_causes},
                correlation_id=message.correlation_id,
            )
        except Exception:
            self.status = "idle"
            raise
