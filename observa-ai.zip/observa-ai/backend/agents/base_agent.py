"""
Base Agent — Google ADK pattern
Every specialist agent inherits from this class.
"""
import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class AgentMessage:
    """Inter-agent communication envelope (MCP protocol message)."""
    sender: str
    recipient: str
    msg_type: str          # request | response | event | broadcast
    payload: Dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    correlation_id: Optional[str] = None


class BaseAgent:
    """
    Base class for all ObservaAI specialist agents.
    Follows Google Agent Development Kit (ADK) design:
      - Declarative role + tool manifest
      - Async message-based communication
      - Status lifecycle (idle → busy → idle)
    """

    def __init__(self, agent_id: str, name: str, description: str):
        self.agent_id = agent_id
        self.name = name
        self.description = description
        self.status: str = "idle"
        self.tools: List[str] = []
        self.tasks_completed: int = 0
        self.message_queue: asyncio.Queue = asyncio.Queue()

    # ── Tool manifest ──────────────────────────────────────────────────────
    def register_tools(self, tools: List[str]) -> None:
        self.tools = tools

    # ── Lifecycle ──────────────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Override in subclasses."""
        raise NotImplementedError

    def _begin_task(self) -> None:
        self.status = "busy"

    def _end_task(self) -> None:
        self.status = "idle"
        self.tasks_completed += 1

    # ── Serialise ──────────────────────────────────────────────────────────
    def get_info(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "tools": self.tools,
            "tasks_completed": self.tasks_completed,
        }
