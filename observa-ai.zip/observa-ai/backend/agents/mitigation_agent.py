"""
MitigationAgent
Maps anomaly patterns to runbook actions and kubectl commands.
"""
from typing import Dict, List, Optional

from agents.base_agent import BaseAgent, AgentMessage


RUNBOOK_BASE = "https://runbooks.internal"

PLAYBOOKS: Dict[str, List[Dict]] = {
    "cpu": [
        {
            "action": "Horizontal Pod Autoscale — add 2 replicas",
            "command": "kubectl scale deployment {service} --replicas=$(kubectl get deployment {service} -o jsonpath='{{.spec.replicas}}' | awk '{{print $1+2}}')",
            "impact": "Distribute CPU load across extra pods — ~40% reduction in ~90 s",
            "auto": True,
            "runbook": f"{RUNBOOK_BASE}/cpu-spike",
        },
        {
            "action": "Enable CPU throttling alerts at 75%",
            "command": None,
            "impact": "Earlier warning before SLO breach",
            "auto": False,
            "runbook": f"{RUNBOOK_BASE}/alert-tuning",
        },
    ],
    "memory": [
        {
            "action": "Rolling restart to reclaim leaked memory",
            "command": "kubectl rollout restart deployment/{service}",
            "impact": "Frees heap, brief 30 s downtime per pod",
            "auto": False,
            "runbook": f"{RUNBOOK_BASE}/memory-leak",
        },
        {
            "action": "Increase JVM/Node heap limit by 25%",
            "command": "kubectl set env deployment/{service} JAVA_OPTS='-Xmx2g'",
            "impact": "Buys time while permanent fix is deployed",
            "auto": True,
            "runbook": f"{RUNBOOK_BASE}/heap-tuning",
        },
    ],
    "error_rate": [
        {
            "action": "Enable circuit-breaker on failing downstream",
            "command": "kubectl apply -f k8s/circuit-breaker-policy.yaml",
            "impact": "Stops retry storms; routes traffic to healthy replicas",
            "auto": True,
            "runbook": f"{RUNBOOK_BASE}/circuit-breaker",
        },
        {
            "action": "Increase connection-pool timeout to 5 s",
            "command": None,
            "impact": "Reduces false DB timeout errors during transient latency",
            "auto": False,
            "runbook": f"{RUNBOOK_BASE}/db-pool",
        },
    ],
    "response_time": [
        {
            "action": "Enable Redis query-result caching (TTL 300 s)",
            "command": "redis-cli CONFIG SET maxmemory-policy allkeys-lru",
            "impact": "60% reduction in DB read load; ~200 ms P99 improvement",
            "auto": True,
            "runbook": f"{RUNBOOK_BASE}/caching",
        },
        {
            "action": "Run EXPLAIN ANALYZE on top-5 slow queries",
            "command": None,
            "impact": "Identifies missing indexes or plan regressions",
            "auto": False,
            "runbook": f"{RUNBOOK_BASE}/db-slow-query",
        },
    ],
    "queue_depth": [
        {
            "action": "Scale consumer worker pool × 2",
            "command": "kubectl scale deployment/{service}-worker --replicas=4",
            "impact": "Halves consumer lag within 2 minutes",
            "auto": True,
            "runbook": f"{RUNBOOK_BASE}/queue-lag",
        },
    ],
}


class MitigationAgent(BaseAgent):

    def __init__(self):
        super().__init__(
            agent_id="mitigation",
            name="Mitigation Advisor",
            description="Runbook-driven automated remediation recommendations",
        )
        self.register_tools([
            "playbook_matcher",
            "kubectl_command_builder",
            "impact_estimator",
            "auto_executor",
            "alert_suppressor",
        ])

    # ── Mitigation builder ─────────────────────────────────────────────────
    def generate(self, anomalies: List[Dict], root_causes: List[Dict]) -> List[Dict]:
        steps: List[Dict] = []
        priority = 1

        for anomaly in anomalies:
            metric   = anomaly.get("metric", "")
            service  = anomaly.get("affected_service", "service")
            severity = anomaly.get("severity", "medium")

            pattern_key = next((k for k in PLAYBOOKS if k in metric), None)
            if not pattern_key:
                continue

            for pb in PLAYBOOKS[pattern_key]:
                cmd = pb["command"]
                if cmd:
                    cmd = cmd.replace("{service}", service)
                steps.append({
                    "priority":            priority,
                    "action":              pb["action"],
                    "command":             cmd,
                    "estimated_impact":    pb["impact"],
                    "automation_possible": pb["auto"],
                    "severity":            severity,
                    "runbook_url":         pb.get("runbook"),
                })
                priority += 1

        if not steps:
            steps.append({
                "priority": 1,
                "action": "Monitor — no actionable anomaly detected",
                "command": None,
                "estimated_impact": "Continue baseline observation",
                "automation_possible": False,
                "severity": "low",
                "runbook_url": None,
            })

        return steps

    # ── BaseAgent interface ────────────────────────────────────────────────
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        self._begin_task()
        try:
            anomalies   = message.payload.get("anomalies", [])
            root_causes = message.payload.get("root_causes", [])
            steps = self.generate(anomalies, root_causes)
            self._end_task()
            return AgentMessage(
                sender=self.agent_id,
                recipient=message.sender,
                msg_type="response",
                payload={"mitigation_steps": steps},
                correlation_id=message.correlation_id,
            )
        except Exception:
            self.status = "idle"
            raise
