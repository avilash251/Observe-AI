/**
 * Formatting utilities used across components.
 */

export const fmt    = (n, d = 1) => (typeof n === "number" ? n.toFixed(d) : "—");
export const fmtPct = (n)        => fmt(n) + "%";
export const fmtMs  = (n)        => fmt(n, 0) + "ms";
export const fmtRps = (n)        => fmt(n, 0) + "/s";
export const clamp  = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

export const severityOf = (value) =>
  value >= 90 ? "critical"
  : value >= 75 ? "high"
  : value >= 60 ? "medium"
  : "ok";

export const metricLabel = (key) =>
  key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
