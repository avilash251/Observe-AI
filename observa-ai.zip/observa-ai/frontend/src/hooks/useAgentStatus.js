/**
 * useAgentStatus — polls /api/agents/status every 3 s
 */
import { useEffect } from "react";
import { api }       from "@/services/api";
import { useStore }  from "@/store/useStore";

export function useAgentStatus() {
  const setAgentStatus = useStore((s) => s.setAgentStatus);

  useEffect(() => {
    const poll = async () => {
      try {
        const data = await api.agentStatus();
        setAgentStatus(data);
      } catch (_) {}
    };

    poll();
    const id = setInterval(poll, 3000);
    return () => clearInterval(id);
  }, []);
}
