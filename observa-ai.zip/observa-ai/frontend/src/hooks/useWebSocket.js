/**
 * useWebSocket
 * Connects the wsClient singleton to the Zustand store.
 * Call once at the App root.
 */
import { useEffect } from "react";
import { wsClient } from "@/services/wsClient";
import { useStore  } from "@/store/useStore";

export function useWebSocket() {
  const setConnected       = useStore((s) => s.setConnected);
  const setLiveMetrics     = useStore((s) => s.setLiveMetrics);
  const setAnomalyResult   = useStore((s) => s.setAnomalyResult);
  const setPredictionResult= useStore((s) => s.setPredictionResult);
  const setAgentThinking   = useStore((s) => s.setAgentThinking);
  const appendAgentStream  = useStore((s) => s.appendAgentStream);
  const resetAgentStream   = useStore((s) => s.resetAgentStream);
  const setAnalyzeLoading  = useStore((s) => s.setAnalyzeLoading);
  const setPredictLoading  = useStore((s) => s.setPredictLoading);

  useEffect(() => {
    wsClient.connect();

    const unsubs = [
      wsClient.subscribe("__connected__",    () => setConnected(true)),
      wsClient.subscribe("__disconnected__", () => setConnected(false)),
      wsClient.subscribe("metrics_update",   (m) => setLiveMetrics(m.data)),

      wsClient.subscribe("anomaly_result",   (m) => {
        setAnomalyResult(m.data);
        setAnalyzeLoading(false);
      }),
      wsClient.subscribe("prediction_result", (m) => {
        setPredictionResult(m.data);
        setPredictLoading(false);
      }),

      wsClient.subscribe("agent_thinking",   (m) => setAgentThinking(m.message)),
      wsClient.subscribe("agent_stream",     (m) => appendAgentStream(m.chunk)),
      wsClient.subscribe("agent_complete",   ()  => setAgentThinking("")),
    ];

    return () => {
      unsubs.forEach((u) => u());
    };
  }, []);

  // Actions
  const analyzeAnomalies = (metrics) => {
    setAnalyzeLoading(true);
    wsClient.send({ type: "analyze_anomaly", payload: { metrics } });
  };

  const runForecast = (payload) => {
    setPredictLoading(true);
    wsClient.send({ type: "predict", payload });
  };

  const sendAgentQuery = (query) => {
    resetAgentStream();
    setAgentThinking("Routing to specialist agents…");
    wsClient.send({ type: "agent_query", query });
  };

  return { analyzeAnomalies, runForecast, sendAgentQuery };
}
