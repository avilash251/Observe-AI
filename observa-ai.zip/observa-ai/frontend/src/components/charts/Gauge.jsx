import { C, SEV_COLOR } from "@/styles/tokens";
import { clamp, severityOf } from "@/utils/formatters";

export function Gauge({ value = 0, size = 80 }) {
  const r     = size / 2 - 8;
  const circ  = 2 * Math.PI * r;
  const pct   = clamp(value, 0, 100) / 100;
  const dash  = pct * circ * 0.75;
  const gap   = circ - dash;
  const color = SEV_COLOR[severityOf(value)];

  return (
    <svg width={size} height={size} style={{ transform: "rotate(135deg)" }}>
      {/* Track */}
      <circle cx={size/2} cy={size/2} r={r}
        fill="none" stroke={C.border} strokeWidth="6"
        strokeDasharray={`${circ * 0.75} ${circ * 0.25}`}
        strokeLinecap="round" />
      {/* Value arc */}
      <circle cx={size/2} cy={size/2} r={r}
        fill="none" stroke={color} strokeWidth="6"
        strokeDasharray={`${dash} ${gap + circ * 0.25}`}
        strokeLinecap="round"
        style={{ filter: `drop-shadow(0 0 5px ${color})` }} />
      {/* Label */}
      <text x={size/2} y={size/2 + 4}
        textAnchor="middle" fill={color}
        fontSize={size > 70 ? 16 : 11} fontWeight="700"
        style={{ transform: "rotate(-135deg)", transformOrigin: `${size/2}px ${size/2}px` }}>
        {Math.round(value)}
      </text>
    </svg>
  );
}
