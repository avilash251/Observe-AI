import { C } from "@/styles/tokens";

export function Sparkline({ data = [], color = C.cyan, width = 120, height = 40 }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data) || 1;
  const W = width, H = height;

  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * W;
    const y = H - ((v - min) / ((max - min) || 1)) * H;
    return `${x},${y}`;
  });
  const gradId = `sg-${color.replace(/[^a-z0-9]/gi, "")}`;

  return (
    <svg width={W} height={H} style={{ display: "block", overflow: "visible" }}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0"   />
        </linearGradient>
      </defs>
      <polygon
        points={`0,${H} ${pts.join(" ")} ${W},${H}`}
        fill={`url(#${gradId})`} />
      <polyline
        points={pts.join(" ")}
        fill="none" stroke={color} strokeWidth="1.5" />
    </svg>
  );
}
