import { AreaChart, Area, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, ComposedChart } from "recharts";
import { C } from "@/styles/tokens";

const TIP = {
  contentStyle: { background: C.surface, border: `1px solid ${C.borderHigh}`, borderRadius: 8, fontSize: 11 },
};

export function ForecastChart({ predictions }) {
  if (!predictions?.predictions?.length) {
    return (
      <div style={{ color: C.textDim, fontSize: 12, padding: 20, textAlign: "center" }}>
        Click "Run Forecast" to view predictive analytics
      </div>
    );
  }

  const pred = predictions.predictions[0];
  const data = pred.predictions?.map((p) => ({
    t:     `+${p.time_offset_minutes}m`,
    value: p.predicted_value,
    upper: p.confidence_upper,
    lower: p.confidence_lower,
  })) || [];

  return (
    <ResponsiveContainer width="100%" height={160}>
      <ComposedChart data={data}>
        <defs>
          <linearGradient id="fcGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor={C.cyan} stopOpacity="0.25" />
            <stop offset="100%" stopColor={C.cyan} stopOpacity="0"    />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
        <XAxis dataKey="t" stroke={C.textDim} tick={{ fontSize: 10 }} />
        <YAxis stroke={C.textDim} tick={{ fontSize: 10 }} />
        <Tooltip {...TIP} />
        {/* Confidence band */}
        <Area type="monotone" dataKey="upper" stroke="none" fill={C.cyan} fillOpacity={0.12} />
        <Area type="monotone" dataKey="lower" stroke="none" fill={C.bg}   fillOpacity={1}    />
        {/* Forecast line */}
        <Line type="monotone" dataKey="value" stroke={C.cyan} strokeWidth={2} dot={false} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
