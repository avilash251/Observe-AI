import { AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { C } from "@/styles/tokens";

const TIP = {
  contentStyle: { background: C.surface, border: `1px solid ${C.borderHigh}`, borderRadius: 8, fontSize: 11 },
  labelStyle:   { color: C.textDim },
};

export function ClusterChart({ data = [], dataKey, color, label }) {
  const gradId = `cg-${dataKey}`;
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16 }}>
      <div style={{ fontSize: 11, color: C.textDim, marginBottom: 12, letterSpacing: 2 }}>
        {label}
      </div>
      <ResponsiveContainer width="100%" height={120}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stopColor={color} stopOpacity="0.4" />
              <stop offset="100%" stopColor={color} stopOpacity="0"   />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={C.border} strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="t" stroke={C.textDim} tick={{ fontSize: 9 }} interval="preserveStartEnd" />
          <YAxis domain={[0, 100]} stroke={C.textDim} tick={{ fontSize: 9 }} />
          <Tooltip {...TIP} />
          <Area type="monotone" dataKey={dataKey}
            stroke={color} fill={`url(#${gradId})`} strokeWidth={2} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
