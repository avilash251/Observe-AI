import { useState }      from "react";
import { C, SEV_COLOR }  from "@/styles/tokens";

export function MitigationCard({ step }) {
  const [executed, setExecuted] = useState(false);
  const autoColor = step.automation_possible ? C.green : C.amber;

  return (
    <div style={{
      background: C.surfaceHigh, border: `1px solid ${C.border}`,
      borderRadius: 8, padding: "12px 14px", marginBottom: 8,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ flex: 1, marginRight: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>
            #{step.priority} — {step.action}
          </div>

          {step.command && (
            <div style={{
              fontFamily: "monospace", fontSize: 10, color: C.cyan,
              background: "#001520", borderRadius: 4, padding: "4px 8px", marginTop: 6,
            }}>
              $ {step.command}
            </div>
          )}

          <div style={{ fontSize: 10, color: C.textDim, marginTop: 4 }}>
            {step.estimated_impact}
          </div>

          {step.runbook_url && (
            <a href={step.runbook_url} target="_blank" rel="noreferrer"
              style={{ fontSize: 10, color: C.cyanDim, marginTop: 4, display: "block" }}>
              📖 runbook
            </a>
          )}
        </div>

        {step.automation_possible && (
          <button onClick={() => setExecuted(true)} style={{
            background: executed ? `${C.green}20` : "transparent",
            border: `1px solid ${executed ? C.green : autoColor}`,
            color: executed ? C.green : autoColor,
            fontSize: 10, fontWeight: 700, padding: "5px 10px",
            borderRadius: 6, cursor: "pointer", letterSpacing: 1,
            whiteSpace: "nowrap", fontFamily: "inherit",
          }}>
            {executed ? "✓ DONE" : "AUTO RUN"}
          </button>
        )}
      </div>
    </div>
  );
}
