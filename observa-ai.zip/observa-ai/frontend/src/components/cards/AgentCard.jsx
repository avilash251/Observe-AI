import { C } from "@/styles/tokens";

const ICONS = {
  anomaly_detector: "⚡",
  predictor:        "🔮",
  root_cause:       "🔍",
  mitigation:       "🛡",
  data_collector:   "📡",
};

export function AgentCard({ agent }) {
  const busy = agent.status === "busy";
  const always = agent.status === "active";
  const statusColor = always ? C.green : busy ? C.amber : C.textDim;

  return (
    <div style={{
      background: C.surfaceHigh,
      border: `1px solid ${busy ? C.amber : C.border}`,
      borderRadius: 8, padding: "10px 14px",
      display: "flex", alignItems: "center", gap: 10,
      transition: "border-color .3s",
    }}>
      <span style={{ fontSize: 20 }}>{ICONS[agent.agent_id || agent.id] || "🤖"}</span>

      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.text, letterSpacing: 1 }}>
          {agent.name}
        </div>
        <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>
          {agent.description}
        </div>
        <div style={{ display: "flex", gap: 4, marginTop: 5, flexWrap: "wrap" }}>
          {(agent.tools || []).slice(0, 3).map((t) => (
            <span key={t} style={{
              fontSize: 9, padding: "1px 6px", borderRadius: 3,
              background: `${C.cyan}15`, color: C.cyan, letterSpacing: 0.5,
            }}>{t}</span>
          ))}
        </div>
      </div>

      <div style={{ textAlign: "right" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, justifyContent: "flex-end" }}>
          <span className={busy ? "blink" : ""} style={{
            width: 7, height: 7, borderRadius: "50%",
            background: statusColor,
            boxShadow: (busy || always) ? `0 0 6px ${statusColor}` : "none",
          }} />
          <span style={{ fontSize: 10, color: statusColor, textTransform: "uppercase", letterSpacing: 1 }}>
            {agent.status}
          </span>
        </div>
        <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>
          {agent.tasks_completed} tasks
        </div>
      </div>
    </div>
  );
}
