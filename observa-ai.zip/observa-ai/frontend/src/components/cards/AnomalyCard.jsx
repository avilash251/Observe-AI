import { C, SEV_COLOR } from "@/styles/tokens";
import { fmt }           from "@/utils/formatters";

export function AnomalyCard({ anomaly, isNew = false }) {
  const color = SEV_COLOR[anomaly.severity] ?? C.text;
  return (
    <div className={isNew ? "slide-in" : ""} style={{
      background: C.surfaceHigh, borderLeft: `3px solid ${color}`,
      borderRadius: 8, padding: "12px 14px", marginBottom: 8,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <span style={{
            fontSize: 10, background: `${color}25`, color, borderRadius: 4,
            padding: "2px 7px", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase",
          }}>
            {anomaly.severity}
          </span>
          <div style={{ fontSize: 12, color: C.text, marginTop: 6, fontWeight: 600 }}>
            {(anomaly.metric || "").replace(/_/g, " ").toUpperCase()}
          </div>
          <div style={{ fontSize: 11, color: C.textDim, marginTop: 2 }}>
            {anomaly.description || anomaly.affected_service}
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 18, fontWeight: 800, color, fontFamily: "monospace" }}>
            {fmt(anomaly.current_value ?? anomaly.value)}
          </div>
          {anomaly.z_score != null && (
            <div style={{ fontSize: 10, color: C.textDim }}>
              z = {fmt(anomaly.z_score, 2)}σ
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
