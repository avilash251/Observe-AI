import { C, FONT_DISPLAY } from "@/styles/tokens";
import { fmt }              from "@/utils/formatters";

export function KpiCard({ label, value, unit = "", color = C.cyan, icon }) {
  return (
    <div style={{
      background: C.surface, border: `1px solid ${C.border}`,
      borderRadius: 10, padding: "14px 16px",
    }}>
      <div style={{ fontSize: 9, color: C.textDim, letterSpacing: 2, marginBottom: 8 }}>
        {icon && <span style={{ marginRight: 5 }}>{icon}</span>}{label}
      </div>
      <div style={{
        fontFamily: FONT_DISPLAY, fontSize: 22, fontWeight: 800, color,
      }}>
        {fmt(value, label.includes("SLO") ? 3 : 1)}
        <span style={{ fontSize: 12, fontWeight: 400 }}>{unit}</span>
      </div>
    </div>
  );
}
