import { C, FONT_DISPLAY } from "@/styles/tokens";
import { useStore }         from "@/store/useStore";

const TABS = ["overview", "services", "anomalies", "predictions", "agents"];

export function TopBar() {
  const connected    = useStore((s) => s.connected);
  const liveMetrics  = useStore((s) => s.liveMetrics);
  const activeTab    = useStore((s) => s.activeTab);
  const setActiveTab = useStore((s) => s.setActiveTab);

  return (
    <header style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "0 24px", height: 56,
      background: C.surface, borderBottom: `1px solid ${C.border}`,
      position: "sticky", top: 0, zIndex: 100,
    }}>
      {/* Brand */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span style={{
          width: 34, height: 34, borderRadius: 8,
          background: `${C.cyan}18`, border: `1px solid ${C.cyan}`,
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
        }}>⬡</span>
        <div>
          <div style={{ fontFamily: FONT_DISPLAY, fontSize: 15, fontWeight: 800,
                        letterSpacing: 2, color: C.cyan }}>
            OBSERVA<span style={{ color: C.text }}>AI</span>
          </div>
          <div style={{ fontSize: 9, color: C.textDim, letterSpacing: 3 }}>
            ANOMALY DETECTION PLATFORM
          </div>
        </div>
      </div>

      {/* Tabs */}
      <nav style={{ display: "flex", gap: 4 }}>
        {TABS.map((t) => (
          <button key={t} onClick={() => setActiveTab(t)}
            style={{
              background:  activeTab === t ? `${C.cyan}15` : "transparent",
              border:      `1px solid ${activeTab === t ? C.cyan : "transparent"}`,
              color:       activeTab === t ? C.cyan : C.textDim,
              padding:     "6px 14px", borderRadius: 6, cursor: "pointer",
              fontSize: 11, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase",
              fontFamily: "inherit",
            }}>
            {t}
          </button>
        ))}
      </nav>

      {/* Status */}
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        {liveMetrics?.anomaly_active && (
          <span style={{
            fontSize: 10, color: C.red, background: `${C.red}20`,
            border: `1px solid ${C.red}`, borderRadius: 20,
            padding: "3px 12px", fontWeight: 700, letterSpacing: 2,
          }} className="blink">
            ⚠ INCIDENT ACTIVE
          </span>
        )}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{
            width: 8, height: 8, borderRadius: "50%",
            background:  connected ? C.green : C.red,
            boxShadow:   connected ? `0 0 6px ${C.green}` : "none",
            animation:   connected ? "pulse 2s infinite" : "none",
          }} />
          <span style={{ fontSize: 10, color: connected ? C.green : C.red, letterSpacing: 2 }}>
            {connected ? "LIVE" : "OFFLINE"}
          </span>
        </div>
      </div>
    </header>
  );
}
