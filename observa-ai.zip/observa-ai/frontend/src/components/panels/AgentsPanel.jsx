import { C } from "@/styles/tokens";
import { useStore }      from "@/store/useStore";
import { AgentCard }     from "@/components/cards/AgentCard";
import { AgentConsole }  from "@/components/panels/AgentConsole";

export function AgentsPanel() {
  const agentStatus = useStore((s) => s.agentStatus);
  const entries     = Object.entries(agentStatus);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>

      {/* Agent registry */}
      <div>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>
          AGENT REGISTRY ({entries.length} agents)
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {entries.length ? (
            entries.map(([id, agent]) => (
              <AgentCard key={id} agent={{ agent_id: id, ...agent }} />
            ))
          ) : (
            <div style={{
              color: C.textDim, fontSize: 12, padding: 20, textAlign: "center",
              background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10,
            }}>
              Connecting to agent registry…
            </div>
          )}
        </div>

        {/* Architecture card */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`,
          borderRadius: 10, padding: 16, marginTop: 14,
        }}>
          <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 10 }}>
            SYSTEM ARCHITECTURE
          </div>
          <pre style={{
            fontSize: 10, lineHeight: 1.9, color: C.textDim,
            fontFamily: "monospace", margin: 0, whiteSpace: "pre-wrap",
          }}>
{`React ──── WebSocket ────► FastAPI
                                │
                        MCP Orchestrator
                                │
           ┌────────────────────┼─────────────────────┐
           │                    │                     │
  AnomalyDetector      PredictorAgent         RootCauseAgent
  Z-score + baseline   ARIMA Smoothing        Dep. Graph
           │                    │                     │
  MitigationAgent        DataCollector         Claude AI
  Runbook+kubectl        Prometheus+Logs       LLM Brain`}
          </pre>
        </div>
      </div>

      {/* AI Console */}
      <div style={{
        background: C.surface, border: `1px solid ${C.border}`,
        borderRadius: 10, padding: 16, display: "flex", flexDirection: "column",
      }}>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>
          🤖 AI AGENT CONSOLE
        </div>
        <AgentConsole />
      </div>
    </div>
  );
}
