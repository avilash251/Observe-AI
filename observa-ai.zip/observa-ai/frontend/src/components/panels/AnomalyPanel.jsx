import { C }                from "@/styles/tokens";
import { fmt }               from "@/utils/formatters";
import { useStore }          from "@/store/useStore";
import { AnomalyCard }       from "@/components/cards/AnomalyCard";
import { MitigationCard }    from "@/components/cards/MitigationCard";
import { Gauge }             from "@/components/charts/Gauge";

export function AnomalyPanel() {
  const anomalyResult  = useStore((s) => s.anomalyResult);
  const analyzeLoading = useStore((s) => s.analyzeLoading);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>

      {/* Left — anomalies + root causes */}
      <div>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>
          DETECTED ANOMALIES
          {analyzeLoading && (
            <span style={{ color: C.amber, marginLeft: 10 }} className="blink">
              ⟳ Analyzing…
            </span>
          )}
        </div>

        {anomalyResult?.anomalies?.length ? (
          anomalyResult.anomalies.map((a, i) => (
            <AnomalyCard key={a.id || i} anomaly={a} isNew={i === 0} />
          ))
        ) : (
          <Empty msg="Run Analysis to detect anomalies in real-time metrics" />
        )}

        {/* Root causes */}
        {anomalyResult?.root_causes?.length > 0 && (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`,
                        borderRadius: 10, padding: 14, marginTop: 10 }}>
            <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 10 }}>
              ROOT CAUSES
            </div>
            {anomalyResult.root_causes.map((rc, i) => (
              <div key={i} style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, color: C.text, fontWeight: 600 }}>{rc.cause}</div>
                <div style={{ fontSize: 10, color: C.cyan, marginTop: 3 }}>
                  Confidence: {Math.round((rc.confidence || 0) * 100)}%
                  {rc.blast_radius && (
                    <span style={{ marginLeft: 10 }}>Blast radius: {rc.blast_radius} services</span>
                  )}
                </div>
                {rc.evidence?.map((e, j) => (
                  <div key={j} style={{ fontSize: 10, color: C.textDim, padding: "1px 0" }}>• {e}</div>
                ))}
              </div>
            ))}
          </div>
        )}

        {/* Health score */}
        {anomalyResult?.overall_health_score != null && (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`,
                        borderRadius: 10, padding: 14, marginTop: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Gauge value={anomalyResult.overall_health_score} size={80} />
              <div>
                <div style={{ fontSize: 10, color: C.textDim, letterSpacing: 2, marginBottom: 4 }}>
                  HEALTH ASSESSMENT
                </div>
                <div style={{ fontSize: 12, color: C.text }}>{anomalyResult.summary}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right — mitigation steps */}
      <div>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>
          MITIGATION STEPS
        </div>
        {anomalyResult?.mitigation_steps?.length ? (
          anomalyResult.mitigation_steps.map((s, i) => (
            <MitigationCard key={i} step={s} />
          ))
        ) : (
          <Empty msg="Mitigation steps appear after anomaly analysis" />
        )}
      </div>
    </div>
  );
}

function Empty({ msg }) {
  return (
    <div style={{
      color: C.textDim, fontSize: 12, padding: 24, textAlign: "center",
      background: C.surface, borderRadius: 10, border: `1px solid ${C.border}`,
    }}>
      {msg}
    </div>
  );
}
