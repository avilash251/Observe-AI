import { C, FONT_DISPLAY } from "@/styles/tokens";
import { fmt }              from "@/utils/formatters";
import { useStore }         from "@/store/useStore";
import { ForecastChart }    from "@/components/charts/ForecastChart";

export function PredictionPanel({ onRunForecast }) {
  const predictionResult = useStore((s) => s.predictionResult);
  const predictLoading   = useStore((s) => s.predictLoading);
  const connected        = useStore((s) => s.connected);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>

      {/* Forecast chart */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2 }}>
            🔮 PREDICTIVE FORECAST (30 min)
          </div>
          <button onClick={onRunForecast} disabled={predictLoading || !connected}
            style={{
              background: `${C.cyan}15`, border: `1px solid ${C.cyan}`, color: C.cyan,
              padding: "6px 14px", borderRadius: 6, cursor: "pointer",
              fontSize: 10, fontWeight: 800, letterSpacing: 2, fontFamily: "inherit",
              opacity: connected ? 1 : 0.5,
            }}>
            {predictLoading ? "⟳ RUNNING…" : "RUN FORECAST"}
          </button>
        </div>

        <ForecastChart predictions={predictionResult} />

        {/* Confidence + trend badges */}
        {predictionResult?.predictions?.[0] && (
          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            {[
              { label: "CONFIDENCE", value: `${Math.round((predictionResult.confidence_score || 0) * 100)}%`, color: C.cyan },
              { label: "TREND",      value: predictionResult.predictions[0].trend?.toUpperCase(), color: C.amber },
              { label: "RISK",       value: predictionResult.predictions[0].risk_level?.toUpperCase(), color: C.red },
            ].map(({ label, value, color }) => (
              <div key={label} style={{
                background: C.surfaceHigh, border: `1px solid ${C.border}`,
                borderRadius: 6, padding: "6px 12px",
              }}>
                <div style={{ fontSize: 9, color: C.textDim, letterSpacing: 2 }}>{label}</div>
                <div style={{ fontSize: 13, fontWeight: 800, color, fontFamily: FONT_DISPLAY }}>
                  {value}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Recommended actions */}
        {predictionResult?.recommended_actions?.length > 0 && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 10, color: C.textDim, letterSpacing: 2, marginBottom: 6 }}>
              RECOMMENDED ACTIONS
            </div>
            {predictionResult.recommended_actions.map((a, i) => (
              <div key={i} style={{
                fontSize: 11, color: C.text, padding: "4px 0",
                borderBottom: `1px solid ${C.border}`,
              }}>
                {i + 1}. {a}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Capacity planner */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 16 }}>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 14 }}>
          ⚠ CAPACITY PLANNER
        </div>

        {predictionResult?.capacity_forecast
          ? <CapacityCards cap={predictionResult.capacity_forecast} />
          : (
            <div style={{ color: C.textDim, fontSize: 12, padding: 20, textAlign: "center" }}>
              Run forecast to see capacity predictions
            </div>
          )
        }
      </div>
    </div>
  );
}

function CapacityCards({ cap }) {
  const entries = [
    { key: "cpu_exhaustion_minutes",    label: "CPU Exhaustion",    unit: "min" },
    { key: "memory_exhaustion_minutes", label: "Memory Exhaustion", unit: "min" },
    { key: "disk_exhaustion_hours",     label: "Disk Full",         unit: "hr"  },
  ];
  const shown = entries.filter(({ key }) => cap[key]);

  if (!shown.length) {
    return (
      <div style={{ color: C.green, fontSize: 12, padding: 10 }}>
        ✓ No capacity issues predicted within the forecast horizon
      </div>
    );
  }

  return shown.map(({ key, label, unit }) => {
    const val    = cap[key];
    const urgent = unit === "min" && val < 30;
    const color  = urgent ? C.red : C.amber;
    return (
      <div key={key} style={{
        background: C.surfaceHigh, border: `1px solid ${color}`,
        borderRadius: 8, padding: "14px 16px", marginBottom: 10,
      }}>
        <div style={{ fontSize: 10, color: C.textDim, letterSpacing: 2 }}>{label.toUpperCase()}</div>
        <div style={{
          fontSize: 26, fontWeight: 800, color, marginTop: 4,
          fontFamily: "'Space Grotesk', sans-serif",
        }}>
          {val}{unit}
        </div>
        {urgent && (
          <div style={{ fontSize: 10, color: C.red, marginTop: 4 }} className="blink">
            ⚠ CRITICAL — TAKE ACTION NOW
          </div>
        )}
      </div>
    );
  });
}
