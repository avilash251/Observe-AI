import { useState, useRef, useEffect } from "react";
import { C }           from "@/styles/tokens";
import { useStore }     from "@/store/useStore";
import { useWebSocket } from "@/hooks/useWebSocket";

const QUICK = [
  "Why is API gateway slow?",
  "Predict next 30 min",
  "Auto-remediate high CPU",
  "Show service dependencies",
];

export function AgentConsole() {
  const { sendAgentQuery } = useWebSocket();
  const agentThinking = useStore((s) => s.agentThinking);
  const agentStream   = useStore((s) => s.agentStream);
  const [query, setQuery] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [agentStream]);

  const submit = () => {
    if (!query.trim()) return;
    sendAgentQuery(query.trim());
    setQuery("");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Stream output */}
      <div style={{
        flex: 1, overflowY: "auto", padding: 14,
        fontFamily: "monospace", fontSize: 11, lineHeight: 1.8, color: C.text,
        background: "#020810", borderRadius: 8, minHeight: 180, maxHeight: 280,
      }}>
        {agentThinking && (
          <div style={{ color: C.amber, marginBottom: 6 }} className="blink">
            ⟳ {agentThinking}
          </div>
        )}
        {agentStream ? (
          <pre style={{ whiteSpace: "pre-wrap", margin: 0 }}>{agentStream}</pre>
        ) : (
          <div style={{ color: C.textMuted }}>
            Ask the multi-agent system anything about your infrastructure…
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="e.g. Why is auth-service failing? What will memory do in 30 min?"
          style={{
            flex: 1, background: C.surfaceHigh, border: `1px solid ${C.borderHigh}`,
            borderRadius: 8, padding: "9px 14px", color: C.text, fontSize: 12,
            outline: "none", fontFamily: "inherit",
          }}
        />
        <button onClick={submit} style={{
          background: C.cyan, color: C.bg, border: "none",
          borderRadius: 8, padding: "0 18px", fontWeight: 800,
          cursor: "pointer", fontSize: 12, letterSpacing: 1, fontFamily: "inherit",
        }}>
          ASK →
        </button>
      </div>

      {/* Quick questions */}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
        {QUICK.map((q) => (
          <button key={q} onClick={() => setQuery(q)} style={{
            fontSize: 10, padding: "4px 10px", background: "transparent",
            border: `1px solid ${C.border}`, color: C.textDim,
            borderRadius: 20, cursor: "pointer", fontFamily: "inherit",
          }}>
            {q}
          </button>
        ))}
      </div>
    </div>
  );
}
