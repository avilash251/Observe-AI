import { C } from "@/styles/tokens";
import { fmt } from "@/utils/formatters";
import { Gauge } from "@/components/charts/Gauge";
import { useStore } from "@/store/useStore";

const HEADERS = ["SERVICE", "CPU", "MEMORY", "P99 LATENCY", "ERROR RATE", "REQ/SEC", "HEALTH"];

function MetricCell({ value, threshold, unit }) {
  const over = value > threshold;
  const warn = value > threshold * 0.8;
  const color = over ? C.red : warn ? C.amber : C.green;
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{
        fontSize: 13, fontWeight: 700, fontFamily: "monospace", color,
      }}>
        {fmt(value)}{unit}
      </div>
    </div>
  );
}

function ServiceRow({ name, metrics }) {
  if (!metrics) return null;
  const statusColor = metrics.status === "degraded" ? C.red : C.green;
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "150px repeat(5, 1fr) 60px",
      gap: 8, alignItems: "center",
      padding: "10px 16px", borderBottom: `1px solid ${C.border}`,
    }}>
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>{name}</div>
        <div style={{ fontSize: 9, color: statusColor, textTransform: "uppercase", letterSpacing: 1 }}>
          ● {metrics.status}
        </div>
      </div>
      <MetricCell value={metrics.cpu_usage}          threshold={80}   unit="%" />
      <MetricCell value={metrics.memory_usage}        threshold={85}   unit="%" />
      <MetricCell value={metrics.response_time_p99}   threshold={1000} unit="ms" />
      <MetricCell value={metrics.error_rate}          threshold={5}    unit="%" />
      <MetricCell value={metrics.request_rate}        threshold={9999} unit="/s" />
      <div style={{ display: "flex", justifyContent: "center" }}>
        <Gauge value={100 - metrics.cpu_usage} size={48} />
      </div>
    </div>
  );
}

export function ServicesTable() {
  const liveMetrics = useStore((s) => s.liveMetrics);
  const services = liveMetrics?.services || {};

  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, overflow: "hidden" }}>
      {/* Header */}
      <div style={{
        display: "grid", gridTemplateColumns: "150px repeat(5, 1fr) 60px",
        gap: 8, padding: "10px 16px",
        background: C.surfaceHigh, borderBottom: `1px solid ${C.border}`,
        fontSize: 9, color: C.textDim, letterSpacing: 2,
      }}>
        {HEADERS.map((h) => (
          <div key={h} style={{ textAlign: h === "SERVICE" ? "left" : "center" }}>{h}</div>
        ))}
      </div>
      {Object.entries(services).map(([name, metrics]) => (
        <ServiceRow key={name} name={name} metrics={metrics} />
      ))}
      {!Object.keys(services).length && (
        <div style={{ padding: 24, textAlign: "center", color: C.textDim, fontSize: 12 }}>
          Waiting for metrics stream…
        </div>
      )}
    </div>
  );
}
