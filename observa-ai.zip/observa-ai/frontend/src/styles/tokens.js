/**
 * Design tokens — single source of truth for all colours and spacing.
 */
export const C = {
  bg:          "#050a0f",
  surface:     "#0a1520",
  surfaceHigh: "#0f1f30",
  border:      "#1a3040",
  borderHigh:  "#244860",

  cyan:        "#00d4ff",
  cyanDim:     "#0090bb",
  green:       "#00ff88",
  greenDim:    "#00bb55",
  amber:       "#ffaa00",
  red:         "#ff3355",
  purple:      "#aa55ff",

  text:        "#c8e8ff",
  textDim:     "#5a8ab0",
  textMuted:   "#2a5070",
};

export const SEV_COLOR = {
  critical: C.red,
  high:     C.amber,
  medium:   C.cyan,
  low:      C.green,
  ok:       C.green,
};

export const FONT_MONO   = "'DM Mono', 'Courier New', monospace";
export const FONT_DISPLAY = "'Space Grotesk', sans-serif";
