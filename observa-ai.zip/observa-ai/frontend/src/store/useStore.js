/**
 * Global state — Zustand store
 * All WebSocket-driven state lives here.
 */
import { create } from "zustand";

export const useStore = create((set, get) => ({
  // Connection
  connected: false,
  setConnected: (v) => set({ connected: v }),

  // Live metrics
  liveMetrics: null,
  metricsHistory: [],   // [{t, cpu, memory, rps, alerts}, ...] max 30
  setLiveMetrics: (data) => {
    const entry = {
      t:       new Date().toLocaleTimeString("en", { timeStyle: "short" }),
      cpu:     data?.global?.cluster_cpu_usage,
      memory:  data?.global?.cluster_memory_usage,
      rps:     data?.global?.total_requests_per_second,
      alerts:  data?.global?.open_alerts,
    };
    set((s) => ({
      liveMetrics:    data,
      metricsHistory: [...s.metricsHistory, entry].slice(-30),
    }));
  },

  // Anomaly result
  anomalyResult:    null,
  analyzeLoading:   false,
  setAnomalyResult: (d) => set({ anomalyResult: d, analyzeLoading: false }),
  setAnalyzeLoading:(v) => set({ analyzeLoading: v }),

  // Prediction result
  predictionResult:   null,
  predictLoading:     false,
  setPredictionResult:(d) => set({ predictionResult: d, predictLoading: false }),
  setPredictLoading:  (v) => set({ predictLoading: v }),

  // Agent state
  agentStatus:    {},
  setAgentStatus: (d) => set({ agentStatus: d }),

  agentThinking:    "",
  setAgentThinking: (v) => set({ agentThinking: v }),

  agentStream:    "",
  appendAgentStream: (chunk) =>
    set((s) => ({ agentStream: s.agentStream + chunk })),
  resetAgentStream: () => set({ agentStream: "" }),

  // Active tab
  activeTab:    "overview",
  setActiveTab: (t) => set({ activeTab: t }),
}));
