import { C, SEV_COLOR } from "@/styles/tokens";
import { fmt, severityOf } from "@/utils/formatters";
import { useStore }      from "@/store/useStore";
import { useWebSocket }  from "@/hooks/useWebSocket";
import { KpiCard }       from "@/components/cards/KpiCard";
import { Gauge }         from "@/components/charts/Gauge";
import { ClusterChart }  from "@/components/charts/ClusterChart";
import { AgentConsole }  from "@/components/panels/AgentConsole";

export function OverviewPage() {
  const liveMetrics    = useStore((s) => s.liveMetrics);
  const metricsHistory = useStore((s) => s.metricsHistory);
  const analyzeLoading = useStore((s) => s.analyzeLoading);
  const predictLoading = useStore((s) => s.predictLoading);
  const connected      = useStore((s) => s.connected);
  const { analyzeAnomalies, runForecast } = useWebSocket();

  const g = liveMetrics?.global || {};
  const health = liveMetrics?.health_score ?? 100;

  const handleAnalyze = () => {
    if (!liveMetrics?.services) return;
    const flat = {};
    Object.entries(liveMetrics.services).forEach(([svc, m]) => {
      Object.entries(m).forEach(([k, v]) => {
        if (typeof v === "number") flat[`${svc}.${k}`] = v;
      });
    });
    analyzeAnomalies(flat);
  };

  const handleForecast = () => {
    runForecast({ cpu: g.cluster_cpu_usage, memory: g.cluster_memory_usage });
  };

  return (
    <div>
      {/* KPI row */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(155px, 1fr))",
        gap: 14, marginBottom: 20,
      }}>
        <KpiCard label="HEALTH SCORE"    value={health}              unit="/100" color={SEV_COLOR[severityOf(health)]}      icon="❤" />
        <KpiCard label="CLUSTER CPU"     value={g.cluster_cpu_usage} unit="%"    color={SEV_COLOR[severityOf(g.cluster_cpu_usage || 0)]}    icon="⚙" />
        <KpiCard label="CLUSTER MEMORY"  value={g.cluster_memory_usage} unit="%" color={SEV_COLOR[severityOf(g.cluster_memory_usage || 0)]} icon="🧠" />
        <KpiCard label="TOTAL RPS"       value={g.total_requests_per_second} unit="/s" color={C.cyan}  icon="↗" />
        <KpiCard label="OPEN ALERTS"     value={g.open_alerts}       unit=""     color={(g.open_alerts || 0) > 0 ? C.red : C.green} icon="🔔" />
        <KpiCard label="SLO COMPLIANCE"  value={g.slo_compliance}    unit="%"    color={C.green} icon="✓" />
      </div>

      {/* Charts */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 20 }}>
        <ClusterChart data={metricsHistory} dataKey="cpu"    color={C.amber}  label="CLUSTER CPU %" />
        <ClusterChart data={metricsHistory} dataKey="memory" color="#aa55ff"  label="CLUSTER MEMORY %" />
      </div>

      {/* Actions + Console */}
      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 14 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <ActionBtn
            label={analyzeLoading ? "⟳ ANALYZING…" : "⚡ ANALYZE ANOMALIES"}
            color={C.red} onClick={handleAnalyze}
            disabled={analyzeLoading || !connected}
          />
          <ActionBtn
            label={predictLoading ? "⟳ FORECASTING…" : "🔮 RUN FORECAST"}
            color={C.cyan} onClick={handleForecast}
            disabled={predictLoading || !connected}
          />
          <div style={{
            background: C.surface, border: `1px solid ${C.border}`,
            borderRadius: 10, padding: 14, textAlign: "center",
          }}>
            <Gauge value={health} size={100} />
            <div style={{ fontSize: 10, color: C.textDim, marginTop: 8, letterSpacing: 2 }}>
              SYSTEM HEALTH
            </div>
          </div>
        </div>

        <div style={{
          background: C.surface, border: `1px solid ${C.border}`,
          borderRadius: 10, padding: 16, display: "flex", flexDirection: "column",
        }}>
          <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>
            🤖 AI AGENT CONSOLE
          </div>
          <AgentConsole />
        </div>
      </div>
    </div>
  );
}

function ActionBtn({ label, color, onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background: disabled ? C.surfaceHigh : `${color}20`,
      border: `1px solid ${color}`, color,
      padding: "13px 16px", borderRadius: 8,
      cursor: disabled ? "not-allowed" : "pointer",
      fontSize: 12, fontWeight: 800, letterSpacing: 2,
      opacity: disabled ? 0.55 : 1,
      fontFamily: "inherit",
    }}>
      {label}
    </button>
  );
}
