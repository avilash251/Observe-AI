import { useWebSocket }     from "@/hooks/useWebSocket";
import { useAgentStatus }   from "@/hooks/useAgentStatus";
import { useStore }         from "@/store/useStore";

import { TopBar }           from "@/components/layout/TopBar";
import { OverviewPage }     from "@/pages/OverviewPage";
import { ServicesTable }    from "@/components/panels/ServicesTable";
import { AnomalyPanel }     from "@/components/panels/AnomalyPanel";
import { PredictionPanel }  from "@/components/panels/PredictionPanel";
import { AgentsPanel }      from "@/components/panels/AgentsPanel";

export default function App() {
  // Boot hooks — connect WS, poll agent status
  const { runForecast } = useWebSocket();
  useAgentStatus();

  const activeTab = useStore((s) => s.activeTab);

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <TopBar />

      <main style={{ flex: 1, padding: 20, overflowY: "auto" }}>
        {activeTab === "overview"     && <OverviewPage />}
        {activeTab === "services"     && <ServicesTable />}
        {activeTab === "anomalies"    && <AnomalyPanel />}
        {activeTab === "predictions"  && <PredictionPanel onRunForecast={() => runForecast({ cpu: 65, memory: 72 })} />}
        {activeTab === "agents"       && <AgentsPanel />}
      </main>
    </div>
  );
}
