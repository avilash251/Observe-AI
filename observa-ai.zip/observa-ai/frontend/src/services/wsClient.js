/**
 * WebSocket client — singleton with auto-reconnect.
 * Consumers register handlers via subscribe().
 */
const WS_BASE = import.meta.env.VITE_WS_URL || "ws://localhost:8000";

class WSClient {
  constructor() {
    this._ws       = null;
    this._handlers = {};   // msg_type → [fn, ...]
    this._clientId = `ui-${Math.random().toString(36).slice(2, 9)}`;
    this._reconnectMs = 3000;
  }

  get clientId() { return this._clientId; }
  get connected() { return this._ws?.readyState === WebSocket.OPEN; }

  connect() {
    if (this._ws && this._ws.readyState < 2) return; // already open/connecting

    const url = `${WS_BASE}/ws/${this._clientId}`;
    this._ws  = new WebSocket(url);

    this._ws.onopen = () => {
      this._emit("__connected__", {});
    };

    this._ws.onclose = () => {
      this._emit("__disconnected__", {});
      setTimeout(() => this.connect(), this._reconnectMs);
    };

    this._ws.onerror = () => this._ws.close();

    this._ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        this._emit(msg.type, msg);
      } catch (_) {}
    };
  }

  send(obj) {
    if (this.connected) {
      this._ws.send(JSON.stringify(obj));
    }
  }

  subscribe(type, fn) {
    if (!this._handlers[type]) this._handlers[type] = [];
    this._handlers[type].push(fn);
    return () => {
      this._handlers[type] = (this._handlers[type] || []).filter((h) => h !== fn);
    };
  }

  _emit(type, payload) {
    (this._handlers[type] || []).forEach((fn) => fn(payload));
    (this._handlers["*"] || []).forEach((fn) => fn(payload));
  }
}

export const wsClient = new WSClient();
