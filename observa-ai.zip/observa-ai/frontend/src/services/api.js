/**
 * REST API client — thin wrappers around fetch()
 */
const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`GET ${path} → ${res.status}`);
  return res.json();
}

async function post(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`POST ${path} → ${res.status}`);
  return res.json();
}

// ── Endpoints ──────────────────────────────────────────────────────────────
export const api = {
  health:           ()       => get("/health"),
  currentMetrics:   ()       => get("/api/metrics/current"),
  listServices:     ()       => get("/api/metrics/services"),
  agentStatus:      ()       => get("/api/agents/status"),
  agentRegistry:    ()       => get("/api/agents/registry"),
  analyzeAnomalies: (payload) => post("/api/anomalies/analyze", payload),
  forecast:         (payload) => post("/api/predictions/forecast", payload),
};
