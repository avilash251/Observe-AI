# ⬡ ObservaAI — Anomaly Detection & Predictive Analytics Platform

> Real-time observability platform powered by a 5-agent AI system (Google ADK + MCP),
> FastAPI WebSocket streaming, React dashboard, and Claude Sonnet for LLM intelligence.

```
observa-ai/
├── backend/                    ← Python FastAPI backend
│   ├── main.py                 ← App entry point + WebSocket routing
│   ├── agents/                 ← 5 specialist AI agents (Google ADK pattern)
│   ├── mcp/                    ← MCP Orchestrator (agent coordinator)
│   ├── models/                 ← Pydantic data models
│   ├── routers/                ← REST API route handlers
│   ├── services/               ← Business logic services
│   └── utils/                  ← Shared utilities
├── frontend/                   ← React 18 + Vite frontend
│   └── src/
│       ├── components/
│       │   ├── charts/         ← Recharts chart components
│       │   ├── panels/         ← Feature panels (Anomaly, Prediction…)
│       │   ├── cards/          ← KPI, Agent, Metric cards
│       │   └── layout/         ← TopBar, TabNav, layout shell
│       ├── hooks/              ← Custom React hooks
│       ├── pages/              ← Page-level components
│       ├── services/           ← API + WebSocket client
│       ├── store/              ← Global state
│       ├── styles/             ← Design tokens + global CSS
│       └── utils/              ← Formatters, helpers
├── docker-compose.yml
└── .env.example
```

## Quick Start

```bash
# 1. Copy env file
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# 2. Docker (recommended)
docker-compose up --build

# 3. Open dashboard
open http://localhost:3000
```

## Manual Setup

```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

## Architecture

```
React Dashboard ◄──── WebSocket ────► FastAPI Backend
                                            │
                                    MCP Orchestrator
                                            │
                         ┌──────────────────┼──────────────────┐
                         │                  │                   │
                  AnomalyDetector    PredictorAgent      RootCauseAgent
                  (Z-score + ML)    (ARIMA Forecast)   (Dep. Tracing)
                         │                  │                   │
                  MitigationAgent    DataCollector         Claude AI
                  (Auto-Remediate)  (Metrics Ingest)   (LLM Analysis)
```
